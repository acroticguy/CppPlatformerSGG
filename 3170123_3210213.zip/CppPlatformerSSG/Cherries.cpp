#include "Cherries.h"

void Cherries::update(float dt)
{
	PowerUp::update(dt);
}

void Cherries::init()
{
	PowerUp::init();
}

void Cherries::draw()
{
	PowerUp::draw();
}

void Cherries::activation(float dt)
{
	PowerUp::activation(dt);
}