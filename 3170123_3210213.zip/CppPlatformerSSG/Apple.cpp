#include "Apple.h"

void Apple::update(float dt)
{
	PowerUp::update(dt);
}

void Apple::init()
{
	PowerUp::init();
}

void Apple::draw()
{
	PowerUp::draw();
}

void Apple::activation(float dt)
{
	PowerUp::activation(dt);
}
