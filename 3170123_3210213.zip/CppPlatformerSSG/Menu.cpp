#include "Menu.h"
#include "GameState.h"

Menu::Menu() : title(""), m_state(GameState::getInstance())
{
}