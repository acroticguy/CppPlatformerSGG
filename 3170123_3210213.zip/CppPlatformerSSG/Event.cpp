#include "Event.h"

void Event::update(float dt)
{
	GameObject::update(dt);
}

void Event::init()
{
}

void Event::draw()
{
}

Event::~Event()
{
}
