#include "Strawberry.h"

void Strawberry::update(float dt)
{
	PowerUp::update(dt);
}

void Strawberry::init()
{
	PowerUp::init();
}

void Strawberry::draw()
{
	PowerUp::draw();
}

void Strawberry::activation(float dt)
{
	PowerUp::activation(dt);
}