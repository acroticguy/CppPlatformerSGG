#include "Melon.h"

void Melon::update(float dt)
{
	PowerUp::update(dt);
}

void Melon::init()
{
	PowerUp::init();
}

void Melon::draw()
{
	PowerUp::draw();
}

void Melon::activation(float dt)
{
	PowerUp::activation(dt);
}