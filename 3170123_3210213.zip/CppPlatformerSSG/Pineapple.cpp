#include "Pineapple.h"

void Pineapple::update(float dt)
{
	PowerUp::update(dt);
}

void Pineapple::init()
{
	PowerUp::init();
}

void Pineapple::draw()
{
	PowerUp::draw();
}

void Pineapple::activation(float dt)
{
	PowerUp::activation(dt);
}