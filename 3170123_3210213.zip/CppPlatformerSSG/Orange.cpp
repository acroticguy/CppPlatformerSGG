#include "Orange.h"

void Orange::update(float dt)
{
	PowerUp::update(dt);
}

void Orange::init()
{
	PowerUp::init();
}

void Orange::draw()
{
	PowerUp::draw();
}

void Orange::activation(float dt)
{
	PowerUp::activation(dt);
}