#include "Kiwi.h"

void Kiwi::update(float dt)
{
	PowerUp::update(dt);
}

void Kiwi::init()
{
	PowerUp::init();
}

void Kiwi::draw()
{
	PowerUp::draw();
}

void Kiwi::activation(float dt)
{
	PowerUp::activation(dt);
}