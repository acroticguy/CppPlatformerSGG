#include "Bananas.h"

void Bananas::update(float dt)
{
	PowerUp::update(dt);
}

void Bananas::init()
{
	PowerUp::init();
}

void Bananas::draw()
{
	PowerUp::draw();
}

void Bananas::activation(float dt)
{
	PowerUp::activation(dt);
}